export default function Page() {
  return <h1>Hello World</h1>
}