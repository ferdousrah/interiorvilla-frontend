export { HeroSection } from "./HeroSection";
export { AboutSection } from "./AboutSection";
export { ProcessSection } from "./ProcessSection";
export { ProjectsSection } from "./ProjectsSection";
export { CTASection } from "./CTASection";