export { HeroSection } from "./HeroSection";
export { ProjectsSection } from "./ProjectsSection";
export { CTASection } from "./CTASection/CTASection";