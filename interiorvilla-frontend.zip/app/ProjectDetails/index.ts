// index.ts
export { default as ProjectDetails } from "./ProjectDetails";