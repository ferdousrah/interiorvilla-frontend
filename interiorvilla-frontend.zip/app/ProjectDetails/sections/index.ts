export { HeroSection } from "./HeroSection";
export { ProjectInfoSection } from "./ProjectInfoSection";
export { BeforeAfterSection } from "./BeforeAfterSection";
export { ProjectGallerySection } from "./ProjectGallerySection";
export { CTASection } from "./CTASection";