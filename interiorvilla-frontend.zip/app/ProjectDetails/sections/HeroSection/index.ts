// app/ProjectDetails/sections/HeroSection/index.ts
export { HeroSection } from "./HeroSection";