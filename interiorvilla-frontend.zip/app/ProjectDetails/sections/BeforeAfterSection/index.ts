// app/ProjectDetails/sections/BeforeAfterSection/index.ts
export { BeforeAfterSection } from "./BeforeAfterSection";