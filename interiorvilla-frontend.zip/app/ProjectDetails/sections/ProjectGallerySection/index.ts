// app/ProjectDetails/sections/ProjectGallerySection/index.ts
export { ProjectGallerySection } from "./ProjectGallerySection";