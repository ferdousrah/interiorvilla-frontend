// app/ProjectDetails/sections/CTASection/index.ts
export { CTASection } from "./CTASection";