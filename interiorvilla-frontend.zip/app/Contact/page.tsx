'use client'

import { Contact } from '@/components/screens/Contact'

export default function ContactPage() {
  return <Contact />
}