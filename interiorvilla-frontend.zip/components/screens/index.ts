export { Home } from "./Home/Home";
export { About } from "./About/About";
export { Contact } from "./Contact/Contact";
export { Blog } from "./Blog/Blog";
export { BlogDetails } from "./BlogDetails/BlogDetails";